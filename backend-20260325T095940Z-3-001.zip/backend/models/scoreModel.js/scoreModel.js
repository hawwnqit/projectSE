class Score {
    constructor(value) {
        this.value = value;
    }
}

module.exports = Score;