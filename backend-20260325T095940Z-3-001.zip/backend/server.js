const express = require("express");
const cors = require("cors");
const scoreRoutes = require("./routes/scoreRoutes");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/score", scoreRoutes);

app.listen(3000, () => console.log("Server running on port 3000"));
