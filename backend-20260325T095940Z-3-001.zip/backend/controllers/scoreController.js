let scores = [];

exports.saveScore = (req, res) => {
    const { score } = req.body;
    scores.push(score);
    res.json({ message: "Score saved", scores });
};
